<?php
// Buscar dados da consulta
$sql = "SELECT * FROM consultas WHERE id_consulta=" . $_REQUEST['id_consulta'];
$res = $conn->query($sql);
$consulta = $res->fetch_object();

// Buscar médicos
$sqlM = "SELECT * FROM medicos ORDER BY nome_medico ASC";
$resM = $conn->query($sqlM);
?>

<h1>Editar Consulta</h1>

<form action="?page=salvar_consulta" method="POST">
    <input type="hidden" name="acao" value="editar">
    <input type="hidden" name="id_consulta" value="<?php print $consulta->id_consulta; ?>">

    <div class="mb-3">
        <label>Nome do Paciente</label>
        <input type="text" name="nome_consulta" class="form-control" value="<?php print $consulta->nome_consulta; ?>" required>
    </div>

    <div class="mb-3">
        <label>CPF</label>
        <input type="text" name="cpf_consulta" class="form-control" value="<?php print $consulta->cpf_consulta; ?>" required>
    </div>

    <div class="mb-3">
        <label>Telefone</label>
        <input type="text" name="telefone_consulta" class="form-control" value="<?php print $consulta->telefone_consulta; ?>">
    </div>

    <div class="mb-3">
        <label>E-mail</label>
        <input type="email" name="email_consulta" class="form-control" value="<?php print $consulta->email_consulta; ?>">
    </div>

    <div class="mb-3">
        <label>Endereço</label>
        <input type="text" name="endereco_consulta" class="form-control" value="<?php print $consulta->endereco_consulta; ?>">
    </div>

    <div class="mb-3">
        <label>Data de Nascimento</label>
        <input type="date" name="dt_nasc_consulta" class="form-control" value="<?php print $consulta->dt_nasc_consulta; ?>">
    </div>

    <div class="mb-3">
        <label>Data da Consulta</label>
        <input type="date" name="dt_consulta" class="form-control" value="<?php print $consulta->dt_consulta; ?>" required>
    </div>

    <div class="mb-3">
        <label>Médico</label>
        <select name="medico_id" class="form-control" required>
            <option value="">Selecione o médico</option>
            <?php
                while ($med = $resM->fetch_object()) {
                    $sel = ($med->id_medico == $consulta->medico_id) ? "selected" : "";
                    print "<option value='{$med->id_medico}' $sel>{$med->nome_medico} - {$med->especialidade_medico}</option>";
                }
            ?>
        </select>
    </div>

    <button type="submit" class="btn btn-success">Salvar Alterações</button>
</form>
