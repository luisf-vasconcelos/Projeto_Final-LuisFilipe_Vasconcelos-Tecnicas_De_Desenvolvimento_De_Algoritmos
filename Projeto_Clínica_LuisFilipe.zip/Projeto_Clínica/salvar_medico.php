<?php

switch ($_REQUEST['acao']) {

    case 'cadastrar':

        $nome = $_POST['nome_medico'];
        $email = $_POST['email_medico'];
        $especialidade = $_POST['especialidade_medico'];
        $telefone = $_POST['telefone_medico'];

        $sql = "INSERT INTO medicos 
                (nome_medico, email_medico, especialidade_medico, telefone_medico)
                VALUES ('{$nome}', '{$email}', '{$especialidade}', '{$telefone}')";

        $res = $conn->query($sql);

        if($res){
            print "<script>alert('Médico cadastrado com sucesso');</script>";
            print "<script>location.href='?page=listar_medico';</script>";
        } else {
            print "<script>alert('Erro ao cadastrar');</script>";
        }
    break;



    case 'editar':

        $nome = $_POST['nome_medico'];
        $email = $_POST['email_medico'];
        $especialidade = $_POST['especialidade_medico'];
        $telefone = $_POST['telefone_medico'];

        $sql = "UPDATE medicos SET
                nome_medico='{$nome}',
                email_medico='{$email}',
                especialidade_medico='{$especialidade}',
                telefone_medico='{$telefone}'
                WHERE id_medico=".$_REQUEST['id_medico'];

        $res = $conn->query($sql);

        if($res){
            print "<script>alert('Médico editado com sucesso');</script>";
            print "<script>location.href='?page=listar_medico';</script>";
        } else {
            print "<script>alert('Erro ao editar');</script>";
        }
    break;



    case 'excluir':

        $sql = "DELETE FROM medicos WHERE id_medico=".$_REQUEST['id_medico'];

        $res = $conn->query($sql);

        if($res){
            print "<script>alert('Médico excluído com sucesso');</script>";
            print "<script>location.href='?page=listar_medico';</script>";
        } else {
            print "<script>alert('Erro ao excluir');</script>";
        }
    break;
}
