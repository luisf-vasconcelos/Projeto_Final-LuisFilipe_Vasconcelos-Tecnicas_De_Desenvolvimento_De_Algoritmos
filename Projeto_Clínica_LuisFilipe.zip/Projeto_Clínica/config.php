<?php
    define("HOST", "localhost");
    define("USER", "root");
    define("PASS", "");
    define("BASE", "clinica");
    define("PORT", 3306);


$conn = new mysqli(HOST, USER, PASS, BASE, PORT);

if ($conn->connect_error) {
    die("Erro na conexão: " . $conn->connect_error);
}
?>
