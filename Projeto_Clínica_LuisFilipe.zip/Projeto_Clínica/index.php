<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Clínica de Olhos Hórus</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
</head>

<body>
    <nav class="navbar navbar-expand-lg bg-dark" data-bs-theme="dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Hórus</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                            aria-expanded="false">
                            Médico
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="?page=cadastrar_medico">Cadastrar</a></li>
                            <li><a class="dropdown-item" href="?page=listar_medico">Listar</a></li>
                        </ul>
                    </li>


                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                            aria-expanded="false">
                            Consultas
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="?page=cadastrar_consulta">Agendar</a></li>
                            <li><a class="dropdown-item" href="?page=listar_consulta">Listar</a></li>
                        </ul>
                    </li>
                </ul>
                <form class="d-flex" role="search">
                    <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search" />
                    <button class="btn btn-outline-success" type="submit">Search</button>
                </form>
            </div>
        </div>
    </nav>

    <div class="container mt-3">
        <div class="row">
            <div class="col">
                <?php
                  include('config.php');
                    switch (@$_REQUEST['page']) {
                        // CRUD Médico
                        case 'cadastrar_medico':
                            include("cadastrar_medico.php");
                            break;
                        case 'listar_medico':
                            include("listar_medico.php");
                            break;
                        case 'editar-medico':
                            include("editar_medico.php");
                            break;
                        case 'salvar_medico':
                            include("salvar_medico.php");
                            break;

                             // CRUD consulta
                        case 'cadastrar_consulta':
                            include("cadastrar_consulta.php");
                            break;
                        case 'listar_consulta':
                            include("listar_consulta.php");
                            break;
                        case 'editar_consulta':
                            include("editar_consulta.php");
                            break;
                        case 'salvar_consulta':
                            include("salvar_consulta.php");
                            break;
                        
                        default:
                            print("<h1>Seja bem vindo(a) ao sistema da Clínica Hórus!</h1>");

                    }
                ?>
            </div>
        </div>
    </div>
    <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>