<h1>Cadastrar Médico</h1>

<form action="?page=salvar_medico" method="POST">
    <input type="hidden" name="acao" value="cadastrar">

    <div class="mb-3">
        <label>Nome
            <input type="text" name="nome_medico" class="form-control" required>
        </label>
    </div>

    <div class="mb-3">
        <label>E-mail
            <input type="email" name="email_medico" class="form-control" required>
        </label>
    </div>

    <div class="mb-3">
        <label>Especialidade
            <input type="text" name="especialidade_medico" class="form-control" required>
        </label>
    </div>

    <div class="mb-3">
        <label>Telefone
            <input type="tel" name="telefone_medico" class="form-control" required>
        </label>
    </div>

    <div class="mb-3">
        <button type="submit" class="btn btn-primary">Salvar</button>
    </div>
</form>
