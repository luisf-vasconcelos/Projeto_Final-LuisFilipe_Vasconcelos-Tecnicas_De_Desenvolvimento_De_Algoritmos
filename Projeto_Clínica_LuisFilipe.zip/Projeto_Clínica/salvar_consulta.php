<?php

switch ($_REQUEST['acao']) {

    case 'cadastrar':

        $nome = $_POST['nome_consulta'];
        $cpf = $_POST['cpf_consulta'];
        $tel = $_POST['telefone_consulta'];
        $email = $_POST['email_consulta'];
        $end = $_POST['endereco_consulta'];
        $nasc = $_POST['dt_nasc_consulta'];
        $data = $_POST['dt_consulta'];
        $medico_id = $_POST['medico_id'];

        $sql = "INSERT INTO consultas
            (nome_consulta, cpf_consulta, telefone_consulta, email_consulta,
             endereco_consulta, dt_nasc_consulta, dt_consulta, medico_id)
            VALUES (
                '{$nome}', '{$cpf}', '{$tel}', '{$email}',
                '{$end}', '{$nasc}', '{$data}', {$medico_id}
            )";

           // var_dump($sql); die();

        $res = $conn->query($sql);

        if($res){
            print "<script>alert('Consulta cadastrada!');</script>";
            print "<script>location.href='?page=listar_consulta';</script>";
        } else {
            print "<script>alert('Erro ao cadastrar consulta');</script>";
            print "<script>location.href='?page=listar_consulta';</script>";
        }
    break;



    case 'excluir':

        $sql = "DELETE FROM consultas WHERE id_consulta=".$_REQUEST['id_consulta'];

        $res = $conn->query($sql);

        if($res){
            print "<script>alert('Consulta excluída!');</script>";
            print "<script>location.href='?page=listar_consulta';</script>";
        } else {
            print "<script>alert('Erro ao excluir');</script>";
        }
    break;
}
