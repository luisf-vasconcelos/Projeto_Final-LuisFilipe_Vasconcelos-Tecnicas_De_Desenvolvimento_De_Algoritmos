<?php
// Buscar dados do médico pelo ID
$sql = "SELECT * FROM medicos WHERE id_medico=" . $_REQUEST['id_medico'];
$res = $conn->query($sql);
$medico = $res->fetch_object();
?>

<h1>Editar Médico</h1>

<form action="?page=salvar_medico" method="POST">
    <input type="hidden" name="acao" value="editar">
    <input type="hidden" name="id_medico" value="<?php print $medico->id_medico; ?>">

    <div class="mb-3">
        <label>Nome</label>
        <input type="text" name="nome_medico" class="form-control" value="<?php print $medico->nome_medico; ?>" required>
    </div>

    <div class="mb-3">
        <label>Email</label>
        <input type="email" name="email_medico" class="form-control" value="<?php print $medico->email_medico; ?>">
    </div>

    <div class="mb-3">
        <label>Especialidade</label>
        <input type="text" name="especialidade_medico" class="form-control" value="<?php print $medico->especialidade_medico; ?>" required>
    </div>

    <div class="mb-3">
        <label>Telefone</label>
        <input type="text" name="telefone_medico" class="form-control" value="<?php print $medico->telefone_medico; ?>">
    </div>

    <button type="submit" class="btn btn-success">Salvar Alterações</button>
</form>
