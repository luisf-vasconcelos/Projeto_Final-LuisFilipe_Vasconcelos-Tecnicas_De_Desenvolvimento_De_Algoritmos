<h1>Listar Médicos</h1>

<?php
$sql = "SELECT * FROM medicos";
$res = $conn->query($sql);
$qtd = $res->num_rows;

if ($qtd > 0) {
    print "<p>Encontrou <b>$qtd</b> resultado(s)</p>";

    print "<table class='table table-bordered table-striped table-hover'>";
    print "<tr>";
    print "<th>ID</th>";
    print "<th>Nome</th>";
    print "<th>Email</th>";
    print "<th>Especialidade</th>";
    print "<th>Telefone</th>";
    print "<th>Ações</th>";
    print "</tr>";

    while ($row = $res->fetch_object()) {
        print "<tr>";
        print "<td>{$row->id_medico}</td>";
        print "<td>{$row->nome_medico}</td>";
        print "<td>{$row->email_medico}</td>";
        print "<td>{$row->especialidade_medico}</td>";
        print "<td>{$row->telefone_medico}</td>";
        print "<td>
                <button class='btn btn-success' 
                    onclick=\"location.href='?page=editar_medico&id_medico={$row->id_medico}';\">Editar</button>

                <button class='btn btn-danger'
                    onclick=\"if(confirm('Tem certeza?')){location.href='?page=salvar_medico&acao=excluir&id_medico={$row->id_medico}';}\">Excluir</button>
               </td>";
        print "</tr>";
    }

    print "</table>";
} else {
    print "<p>Não encontrou resultado</p>";
}
?>
